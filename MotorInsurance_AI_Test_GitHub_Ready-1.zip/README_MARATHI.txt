MOTOR INSURANCE AI TEST — ANDROID 16

Test number: 7083473369
Device target: Samsung Galaxy Tab A9+ 5G, Android 16, single SIM

हा Phase-1 technical test आहे.
तो खालील गोष्टी तपासतो:
1) App मधून SIM cellular call सुरू होतो का.
2) Call संपल्याचे app detect करू शकते का.
3) त्याच नंबरला automatic duplicate call block होतो का.
4) Call संपल्यानंतर 60 सेकंद cooldown लागू होतो का.
5) दुसरा call फक्त Call Again + manual confirmation ने होतो का.

हा build अजून AI ला cellular call audio च्या आत बोलू/ऐकू देत नाही. तो पुढील telephony/AI bridge test आहे.

APK build करण्यासाठी:
- Android Studio install करा.
- हा folder Open करा.
- Android SDK 36 install/accept करा.
- Build > Build APK(s).
- तयार APK साधारण app/build/outputs/apk/debug/app-debug.apk येथे असेल.

Install केल्यावर Phone permission Allow करा.
फक्त test/consenting number वापरा.
