# Motor Insurance AI Test — Tablet-only build

This test build is for Samsung Galaxy Tab A9+ 5G / Android 16.

## What this test does
- Starts a normal SIM call to the configured test number.
- Tracks whether that number was already called today.
- Blocks another automatic attempt the same day.
- Allows a second attempt only through the manual "Call Again" confirmation.
- Starts a 60-second cooldown after the call ends.

## What this test does NOT do yet
- AI does not talk to the customer yet.
- Google Sheet, WhatsApp, quotation reading, and lead automation are not yet enabled.

## Cloud build with GitHub Actions
1. Create a private GitHub repository, for example `MotorInsurance-AI-Test`.
2. Upload this project at the repository root.
3. Open the **Actions** tab.
4. Open **Build Android APK** and run the workflow if it did not start automatically.
5. When the run is green, open it and download the artifact named **MotorInsurance-AI-Test-APK**.
6. Extract the downloaded artifact ZIP on the Samsung tablet and install `app-debug.apk`.
7. Allow Phone permission when prompted.

## Safety
Use only a test number that you own or have permission to call. This is a debug test build, not a production release.
