package com.motorinsurance.aitest;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.TelecomManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PHONE = 10;
    private WebView webView;
    private TelecomManager telecom;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean placedByUs = false;
    private boolean seenInCall = false;

    private final Runnable watcher = new Runnable() {
        @Override public void run() {
            try {
                boolean inCall = telecom != null && telecom.isInCall();
                if (placedByUs && inCall) seenInCall = true;
                if (placedByUs && seenInCall && !inCall) {
                    placedByUs = false;
                    seenInCall = false;
                    webView.post(() -> webView.evaluateJavascript(
                        "if(window.onNativeCallEnded){window.onNativeCallEnded();}", null));
                }
            } catch (SecurityException ignored) {}
            handler.postDelayed(this, 1200);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        telecom = (TelecomManager) getSystemService(TELECOM_SERVICE);
        webView = findViewById(R.id.webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(this), "Android");
        requestPermissionsIfNeeded();
        webView.loadUrl("file:///android_asset/test.html");
        handler.post(watcher);
    }

    private void requestPermissionsIfNeeded() {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE}, REQ_PHONE);
        }
    }

    private void placeCall(String raw) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Phone permission आवश्यक आहे", Toast.LENGTH_LONG).show();
            requestPermissionsIfNeeded();
            return;
        }
        String number = raw == null ? "" : raw.replaceAll("[^0-9+]", "");
        if (number.isEmpty()) return;
        try {
            placedByUs = true;
            seenInCall = false;
            telecom.placeCall(Uri.parse("tel:" + number), new Bundle());
        } catch (Exception e) {
            placedByUs = false;
            Toast.makeText(this, "Call सुरू झाला नाही: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public class Bridge {
        private final Context ctx;
        Bridge(Context ctx) { this.ctx = ctx; }
        @JavascriptInterface public void placeCall(String number) { runOnUiThread(() -> placeCall(number)); }
        @JavascriptInterface public String getVersion() { return "0.1-test"; }
        @JavascriptInterface public void resetToday() {
            getSharedPreferences("calllock", MODE_PRIVATE).edit().clear().apply();
            runOnUiThread(() -> webView.reload());
        }
        @JavascriptInterface public boolean wasCalledToday(String number) {
            String key = "called_" + number.replaceAll("[^0-9]", "");
            return getSharedPreferences("calllock", MODE_PRIVATE).getBoolean(key, false);
        }
        @JavascriptInterface public void markCalledToday(String number) {
            String key = "called_" + number.replaceAll("[^0-9]", "");
            getSharedPreferences("calllock", MODE_PRIVATE).edit().putBoolean(key, true).apply();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(watcher);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
